# Update 1 — Runa is safe for surprises

Runa *understood* anything before, but only had two "forms" to fill in, and
crashed or wrote the wrong thing when a message didn't fit. Now:

| # | Change | Where |
|---|--------|-------|
| 1 | "Late" form became **arrival time changed** — early *or* late. The code (not the AI) decides "Early" vs "Delayed" by comparing times. | `pipeline.py` `_gate_and_write` |
| 2 | New **quality complaint** form → creates an SAP quality notification. | `agents.py`, `sap_mock.py` |
| 3 | **Forward to supervisor** when Runa understands something but has no form for it. | `pipeline.py` `_handoff` |
| 4 | **Rulebook check** before every write: delivery must exist, time must be sensible (≤24h shift), shortage ≤ half the delivery. | `pipeline.py` `_policy_check`, limits in `config.py` |
| 5 | **Crash armour**: AI or SAP failure → polite handoff, the bot never dies. | `pipeline.py` `handle`, `agents.py` `_ask` |
| 6 | Only the person asked can answer Runa's question. | `pipeline.py` `self.pending` (keyed by sender) |
| + | "opsi a / opsi b" decisions — now for late *and* early arrivals. | `pipeline.py` `_decide` |
| + | Dock opening time, so "too early" is detectable. | `config.py` |

## New commands

    python test_surprises.py        # 14 checks, fake AI, free, ~5 seconds
    python replay.py surprises      # unrehearsed messages with the real AI
    /reset                          # in Telegram: clean ledger for a new demo take

# Update 2 — fixes from the first real-AI surprise run

The fake-AI tests passed, but the real AI made three mistakes on unrehearsed
messages. Each one now has a fix *and* a test so it stays fixed.

| Problem seen in the real run | Fix | Where |
|---|---|---|
| Asked questions about optional details ("why is it early?", "how many cartons?") | The AI is told exactly which fields each form *requires*. Confidence is only about those; optional details never trigger a question. | `agents.py` `RESOLVER_SYSTEM` |
| Treated a new topic as an answer — the forklift report vanished | Before treating a message as an answer, a quick check asks "is this actually answering the question?" If not, it's processed as a new message and the question stays open. | `agents.py` `match_answer`, `pipeline.py` `_which_answer` |
| Silently swapped DO 0080009999 for Budi's usual 0080004521 | **Code rule**: if the human typed a delivery number, the AI must use exactly that one. Unknown or different number → Runa asks. Short corrections ("yang 4521") work. | `pipeline.py` `_check_delivery_number` |
| "Connection error" hid the real cause | Errors now show what actually failed. | `agents.py` `_ask` |

Tests: 19 (was 14).

# Update 3 — up to two questions, words instead of codes

| Change | Where |
|---|---|
| Runa may ask **up to two** questions per event (was one), so it can fix two separate gaps — e.g. a wrong DO number *and* a missing time. A third would be nagging, so a human takes over. | `pipeline.py` `_ask_or_handoff`, `MAX_QUESTIONS_PER_EVENT` in `config.py` |
| Never asks the exact same question twice — that goes straight to a human. | `pipeline.py` `_ask_or_handoff` |
| Chat replies say *"berangkat lebih awal"*, not *"EARLY_DISPATCH"*. SAP still gets the code. | `pipeline.py` `REASON_TEXT` |
| New replay script for multi-turn threads. | `python replay.py conversations` |

Tests: 23 (was 19).
