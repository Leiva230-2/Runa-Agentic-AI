"""
Surprise tests. Fakes the AI's answers so we test what the CODE does with them.
No API key needed, costs nothing. Run after any change:

    uvicorn sap_mock:app --port 8000     # terminal 1
    python test_surprises.py             # terminal 2
"""
import os
os.environ.setdefault("ANTHROPIC_API_KEY", "not-needed-for-tests")

import httpx

import agents
from config import SAP_BASE
from pipeline import Runa
from trace import Trace

# ------------------------------------------------------------ fake AI ---
class FakeAI:
    """Queue up the answers the AI 'would' give, in order."""
    def __init__(self):
        self.listens, self.resolves, self.decisions, self.answers = [], [], [], []

    def listen(self, message, sender):
        if self.listens:
            return self.listens.pop(0)
        return {"is_event": False, "event_type": None, "summary": ""}

    def resolve(self, *args):
        return self.resolves.pop(0)

    def match_answer(self, message, questions):
        return self.answers.pop(0) if self.answers else {"answers_index": None}

    def interpret_decision(self, message, options):
        return self.decisions.pop(0) if self.decisions else {"choice": None}


def event(kind, summary="test"):
    return {"is_event": True, "event_type": kind, "summary": summary}


def res(did="0080004521", ident=0.95, content=0.95, **fields):
    base = {"delivery_id": did, "identity_confidence": ident,
            "content_confidence": content, "event_type": "ETA_CHANGE",
            "reasoning": "test", "clarifying_question": "Bisa dikonfirmasi?"}
    base.update(fields)
    return base


def fresh():
    httpx.post(f"{SAP_BASE}/_debug/reset", timeout=5)
    ai = FakeAI()
    agents.listen, agents.resolve = ai.listen, ai.resolve
    agents.interpret_decision = ai.interpret_decision
    agents.match_answer = ai.match_answer
    return ai, Runa(Trace(echo=False))


def sap():
    return httpx.get(f"{SAP_BASE}/_debug/state", timeout=5).json()


RESULTS = []


def check(name, condition):
    RESULTS.append((name, condition))
    print(f"  {'PASS' if condition else 'FAIL'}  {name}")


# ---------------------------------------------------------------- tests ---
def test_early_arrival():
    ai, r = fresh()
    ai.listens = [event("ETA_CHANGE")]
    ai.resolves = [res(new_eta="2026-09-09T19:30:00", reason_code="EARLY_DISPATCH")]
    r.handle("Budi", "pak truknya bakal nyampe lebih cepat, jam setengah 8")
    d = sap()["deliveries"]["0080004521"]
    check("Early arrival is recorded as 'Early', not 'Delayed'", d["Status"] == "Early")


def test_early_before_dock_opens_then_decision():
    ai, r = fresh()
    ai.listens = [event("ETA_CHANGE")]
    ai.resolves = [res(did="0080004522", new_eta="2026-09-10T05:30:00")]
    out = r.handle("Rudi", "besok datang subuh jam 5.30")
    check("Arriving before the dock opens raises an EARLY conflict",
          any("baru buka" in m for m in out))
    ai.decisions = [{"choice": "b", "reasoning": "truck waits"}]
    r.handle("Sari", "opsi b aja")
    d = sap()["deliveries"]["0080004522"]
    check("Choosing 'b' makes the truck wait until 06:00",
          d["PlannedGoodsReceipt"] == "2026-09-10T06:00:00")


def test_quality_complaint():
    ai, r = fresh()
    ai.listens = [event("QUALITY_COMPLAINT")]
    ai.resolves = [res(event_type="QUALITY_COMPLAINT",
                       defect_description="Cartons wet from rain", defect_code="WET")]
    r.handle("Sari", "DO 0080004521 kardusnya basah semua")
    check("Quality complaint creates a quality notification in SAP",
          len(sap()["quality_notifications"]) == 1)


def test_no_form_goes_to_human():
    ai, r = fresh()
    ai.listens = [event("OTHER_OPERATIONAL", "Forklift in warehouse 2 is broken")]
    out = r.handle("Sari", "forklift di gudang 2 rusak")
    check("Understood-but-no-form is forwarded to a human",
          r.handoffs == 1 and r.written == 0 and "supervisor" in out[0])


def test_invented_delivery_blocked():
    ai, r = fresh()
    ai.listens = [event("ETA_CHANGE")]
    ai.resolves = [res(did="0080009999", new_eta="2026-09-09T23:00:00")]
    r.handle("Budi", "telat jam 11")
    check("A delivery number that doesn't exist is blocked", r.written == 0 and r.handoffs == 1)


def test_huge_eta_shift_blocked():
    ai, r = fresh()
    ai.listens = [event("ETA_CHANGE")]
    ai.resolves = [res(new_eta="2026-09-12T21:00:00")]
    r.handle("Budi", "baru bisa datang 3 hari lagi")
    check("Moving a delivery by 3 days needs a human", r.written == 0 and r.handoffs == 1)


def test_huge_shortage_blocked():
    ai, r = fresh()
    ai.listens = [event("GOODS_RECEIPT_DISCREPANCY")]
    ai.resolves = [res(event_type="GOODS_RECEIPT_DISCREPANCY", quantity_short=400)]
    r.handle("Sari", "kurang 400 dus")
    check("A shortage over half the delivery needs a human", r.written == 0)


def test_normal_shortage_written():
    ai, r = fresh()
    ai.listens = [event("GOODS_RECEIPT_DISCREPANCY")]
    ai.resolves = [res(event_type="GOODS_RECEIPT_DISCREPANCY", quantity_short=3)]
    r.handle("Sari", "DO 0080004521 kurang 3 dus")
    check("A normal shortage is written", len(sap()["material_documents"]) == 1)


def test_ai_crash_survived():
    ai, r = fresh()
    def broken(*a):
        raise agents.ModelError("simulated outage")
    agents.listen = broken
    out = r.handle("Budi", "macet parah")
    check("An AI outage becomes a polite handoff, not a crash",
          r.handoffs == 1 and "gangguan" in out[0])


def test_sap_down_survived():
    ai, r = fresh()
    ai.listens = [event("ETA_CHANGE")]
    real = agents.get_open_deliveries
    agents.get_open_deliveries = lambda: (_ for _ in ()).throw(httpx.ConnectError("down"))
    out = r.handle("Budi", "macet")
    agents.get_open_deliveries = real
    check("SAP being down becomes a polite handoff, not a crash",
          r.handoffs == 1 and "gangguan" in out[0])


def test_other_person_doesnt_steal_answer():
    ai, r = fresh()
    ai.listens = [event("ETA_CHANGE")]
    ai.resolves = [res(content=0.55, new_eta="2026-09-09T23:00:00")]
    r.handle("Budi", "kayaknya jam 11 malam")
    r.handle("Sari", "pagi semua")          # chatter from someone else
    check("Someone else's message doesn't count as Budi's answer", "Budi" in r.pending)


def test_full_happy_path():
    ai, r = fresh()
    ai.listens = [event("ETA_CHANGE")]
    ai.resolves = [res(content=0.55, new_eta="2026-09-09T23:00:00"),
                   res(content=0.93, new_eta="2026-09-09T23:00:00", reason_code="TRAFFIC")]
    r.handle("Budi", "macet, kayaknya jam 11 malam")
    ai.answers = [{"answers_index": 0}]
    out = r.handle("Budi", "sudah pasti jam 23:00")
    check("Hedge -> ask -> confirm -> write -> late conflict raised",
          r.written == 1 and any("tutup" in m for m in out))
    ai.decisions = [{"choice": "b", "reasoning": "reschedule"}]
    r.handle("Sari", "opsi b runa")
    d = sap()["deliveries"]["0080004521"]
    check("'opsi b runa' reschedules to tomorrow 06:00",
          d["Status"] == "Rescheduled" and d["PlannedGoodsReceipt"] == "2026-09-10T06:00:00")


# ------------------------------- found by the real AI, 1 Oct 2026 run ---
def test_topic_switch_not_swallowed():
    ai, r = fresh()
    ai.listens = [event("QUALITY_COMPLAINT"),
                  event("OTHER_OPERATIONAL", "Forklift broken")]
    ai.resolves = [res(event_type="QUALITY_COMPLAINT", content=0.6,
                       defect_description="wet", defect_code="WET")]
    r.handle("Sari", "DO 0080004521 kardusnya basah")
    ai.answers = [{"answers_index": None}]          # forklift is NOT the answer
    out = r.handle("Sari", "forklift di gudang 2 rusak lagi")
    check("A new topic isn't swallowed as an answer — forklift reaches a human",
          r.handoffs == 1 and "supervisor" in out[0])
    check("...and Runa's original question to Sari stays open", "Sari" in r.pending)


def test_unknown_delivery_number_asks():
    ai, r = fresh()
    ai.listens = [event("ETA_CHANGE")]
    ai.resolves = [res(did="0080004521", new_eta="2026-09-09T23:00:00")]  # AI swaps it
    out = r.handle("Budi", "pak DO 0080009999 telat ya, jam 11 malam")
    check("Unknown DO number: Runa asks instead of using a different delivery",
          r.written == 0 and "0080009999 tidak ada" in out[0])


def test_swapped_delivery_number_asks():
    ai, r = fresh()
    ai.listens = [event("ETA_CHANGE")]
    ai.resolves = [res(did="0080004521", new_eta="2026-09-09T23:00:00")]
    out = r.handle("Budi", "DO 0080004522 telat, jam 11 malam")
    check("Human said 4522, AI picked 4521: Runa asks which one",
          r.written == 0 and "0080004522" in out[0] and "0080004521" in out[0])


def test_short_number_correction_works():
    ai, r = fresh()
    ai.listens = [event("ETA_CHANGE")]
    ai.resolves = [res(did="0080004521", new_eta="2026-09-09T23:00:00"),
                   res(did="0080004521", new_eta="2026-09-09T23:00:00")]
    r.handle("Budi", "pak DO 0080009999 telat, jam 11 malam")
    ai.answers = [{"answers_index": 0}]
    r.handle("Budi", "eh salah, maksudnya yang 4521")
    check("A short correction ('yang 4521') resolves it and the write goes through",
          r.written == 1)


# ------------------------------------------- two-question budget (Update 3) ---
def test_two_questions_for_two_missing_things():
    """Budi's real message: wrong DO number AND no time. Needs two questions."""
    ai, r = fresh()
    ai.listens = [event("ETA_CHANGE")]
    ai.resolves = [
        res(did="0080009999", content=0.45, new_eta=None),            # Q1: bad number
        res(did="0080004521", content=0.45, new_eta=None,
            clarifying_question="Jam berapa kira-kira sampainya?"),    # Q2: no time
        res(did="0080004521", content=0.93, new_eta="2026-09-09T23:00:00",
            reason_code="TRAFFIC"),                                    # now complete
    ]
    q1 = r.handle("Budi", "pak DO 0080009999 telat ya")
    ai.answers = [{"answers_index": 0}]
    q2 = r.handle("Budi", "eh salah, maksudnya yang 4521")
    ai.answers = [{"answers_index": 0}]
    r.handle("Budi", "jam 23:00 pak")
    check("Wrong number + missing time: asks twice, then writes",
          "tidak ada" in q1[0] and "Jam berapa" in q2[0] and r.written == 1)


def test_third_question_goes_to_human():
    ai, r = fresh()
    ai.listens = [event("ETA_CHANGE")]
    vague = dict(content=0.4, new_eta=None)
    ai.resolves = [res(clarifying_question="Jam berapa?", **vague),
                   res(clarifying_question="Kira-kira jam berapa?", **vague),
                   res(clarifying_question="Bisa lebih spesifik?", **vague)]
    r.handle("Budi", "telat nih")
    ai.answers = [{"answers_index": 0}]
    r.handle("Budi", "ya gitu deh")
    ai.answers = [{"answers_index": 0}]
    out = r.handle("Budi", "ga tau pak")
    check("After two unanswered questions, a human takes over (no third question)",
          r.handoffs == 1 and r.written == 0 and "supervisor" in out[0])


def test_never_repeats_same_question():
    ai, r = fresh()
    ai.listens = [event("ETA_CHANGE")]
    same = dict(content=0.4, new_eta=None, clarifying_question="Jam berapa sampainya?")
    ai.resolves = [res(**same), res(**same)]
    r.handle("Budi", "telat nih")
    ai.answers = [{"answers_index": 0}]
    out = r.handle("Budi", "hmm")
    check("Runa never asks the exact same question twice",
          r.handoffs == 1 and "supervisor" in out[0])


def test_chat_shows_words_not_codes():
    ai, r = fresh()
    ai.listens = [event("ETA_CHANGE")]
    ai.resolves = [res(did="0080004522", new_eta="2026-09-10T07:00:00",
                       reason_code="EARLY_DISPATCH")]
    out = r.handle("Rudi", "besok jam 7 sudah sampai")
    check("Chat says 'berangkat lebih awal', not 'EARLY_DISPATCH'",
          "berangkat lebih awal" in out[0] and "EARLY_DISPATCH" not in out[0])


if __name__ == "__main__":
    try:
        httpx.get(f"{SAP_BASE}/_debug/state", timeout=3)
    except Exception:
        raise SystemExit("Start the SAP mock first:  uvicorn sap_mock:app --port 8000")

    print("\nRuna surprise tests\n")
    for name, fn in list(globals().items()):
        if name.startswith("test_"):
            fn()
    passed = sum(ok for _, ok in RESULTS)
    print(f"\n{passed}/{len(RESULTS)} passed\n")
